Iconset: Scripting and programming languages (https://www.iconfinder.com/iconsets/scripting-and-programming-languages)
Author: Icon Designer (https://www.iconfinder.com/icondesigner)
License: Free for commercial use ()
Download date: 2023-02-07